export class Student {
    id: number;
    name: String;
    email: String;
    phone: String;
    addr: String;
    password: String;
    regid:number;
}
