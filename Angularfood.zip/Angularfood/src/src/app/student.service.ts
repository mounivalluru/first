import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';
import { Student } from './student';


@Injectable({
  providedIn: 'root'
})
export class StudentService {

  private basePath = 'http://localhost:8090/rest/Customer';

  constructor(private http: HttpClient) { }


  getAllStudents(): Observable<Student[]> {
    return this.http.get<Student[]>(`${this.basePath}/all`);
  }

  deleteOneStudent(email: String): Observable<any> {
    return this.http.delete(`${this.basePath}/remove/${email}`, {responseType: 'text'});
  }

  createStudent(student: Student): Observable<any> {
    return this.http.post(`${this.basePath}/save`, student, {responseType: 'text'});
  }

  getOneStudent(regid:number): Observable<Student> {
    return this.http.get<Student>(`${this.basePath}/one/${regid}`);
  }

  updateStudent(email: String, student: Student): Observable<any> {
    return this.http.put(`${this.basePath}/modify/${email}`, student, {responseType : 'text'});
  }

}
