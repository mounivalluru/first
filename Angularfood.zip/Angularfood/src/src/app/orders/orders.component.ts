import { Component, OnInit } from '@angular/core';
import { Food } from '../food';
import { FoodService} from './../food.service';
import { Router } from '@angular/router';

@Component({
  selector: 'app-order',
  templateUrl: './orders.component.html',
  styleUrls: ['./orders.component.css']
})
export class OrdersComponent implements OnInit {

  food: Food[];
  message: string;
  // inject service layer
  constructor(private service: FoodService, private router: Router) { }

  // on page load call this method
  ngOnInit(): void {
    this.getAllFood();
  }
  // fetch data from backend application using service
  // tslint:disable-next-line: typedef
  getAllFood() {
    return this.service.getAllFood()
    .subscribe(
      data => {
        this.food = data;
      }, error => {
        console.log(error);
      }
    );
  }
 Feedback()
  {
    this.router.navigate(['/Feedback']);

  }

  // tslint:disable-next-line: typedef
  deleteStudent(food_id: number) {
    if (confirm('Do you want to delete?')) {
      this.service.deleteOneFood(food_id).subscribe(data => {
        this.message = data;
        this.getAllFood();
      }, error => {
        console.log(error);
      });
    } else {
      this.message = '';
    }
  }

}
