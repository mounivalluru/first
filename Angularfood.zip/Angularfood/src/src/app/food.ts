export class Food {
    id:number;
    food_id: number;
    food_name: String;
    food_price:number
}
