export class Feedback{
    id:number;
    name:String;
    email:String;
    message:String;
}
