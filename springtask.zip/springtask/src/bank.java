public class bank {  
	private int accno,balance;  
	private String name,address;  
	public bank() 
	{
		System.out.println("default constructor");
	}  

	public bank(int accno,int balance, String name,String address) 
	{  
		this.accno = accno;  
		this.balance=balance;
		this.name = name;
		this.address=address;
	}  
	void show()
	{  
		System.out.println("Account no is:"+accno+ " Balance : "+balance+ " Name of the holder:"+name+ " Address is: "+address);  
	}
}  