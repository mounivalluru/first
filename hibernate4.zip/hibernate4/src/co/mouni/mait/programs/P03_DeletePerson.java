package co.mouni.mait.programs;

import org.hibernate.HibernateException;
import org.hibernate.Session;

import co.mouni.mait.entity.Person;
import co.mouni.mait.util.HibernateUtil;
import co.mouni.mait.util.KeyboardUtil;

public class P03_DeletePerson {

	public static void main(String[] args) {

		int accno = KeyboardUtil.getInt("Enter accno of the person to delete: ");

		Session session = HibernateUtil.getSession();
		session.beginTransaction();
		try {
			Person p1 = (Person) session.get(Person.class, accno);
			if (p1 == null) {
				System.out.println("No record to delete!");
			} else {
				session.delete(p1);
				session.getTransaction().commit();
				System.out.println("Data deleted successfully!");
			}
		} catch (HibernateException e) {
			System.out.println("Could not delete the data");
			System.err.println(e.getMessage());
			session.getTransaction().rollback();
		}

		session.close();

	}
}
