package co.mouni.mait.programs;

import org.hibernate.HibernateException;
import org.hibernate.Session;
import org.hibernate.Transaction;

import co.mouni.mait.entity.Person;
import co.mouni.mait.util.HibernateUtil;
import co.mouni.mait.util.KeyboardUtil;

public class P02_AddNewPerson {

	public static void main(String[] args) {

		int accno;
		String fname, lname, phone, bankname;

		accno= KeyboardUtil.getInt("Enter accno: ");
		fname = KeyboardUtil.getString("Enter firstname: ");
		lname = KeyboardUtil.getString("Enter lastname: ");
		phone = KeyboardUtil.getString("Enter phone: ");
		bankname = KeyboardUtil.getString("Enter bankname: ");

		Person p1 = new Person(accno, fname, lname, phone, bankname);
		
		
		Session session = HibernateUtil.getSession();
		Transaction tx = session.beginTransaction();
		try {
			session.save(p1);
			tx.commit();
			System.out.println("Data saved to db.");
		} catch (HibernateException e) {
			tx.rollback();
			System.out.println("There was an error while trying to save data.");
			System.out.println(e.getMessage());
		}
		
		session.close();
		

	}
}









