package co.mouni.mait.programs;

import org.hibernate.Session;

import co.mouni.mait.entity.Person;
import co.mouni.mait.util.HibernateUtil;
import co.mouni.mait.util.KeyboardUtil;

public class P04_UpdatePersonData {

	public static void main(String[] args) {
		Session session = HibernateUtil.getSession();
		int accno = KeyboardUtil.getInt("Enter id: ");
		session.beginTransaction();
		Person p1 = (Person) session.get(Person.class, accno);

		if (p1 == null) {
			System.out.println("No data found!");
		} else {
			String input;

			input = KeyboardUtil.getString("First name : (" + p1.getFirstName() + ") ");
			if (!input.equals("")) {
				p1.setFirstName(input);
			}

			input = KeyboardUtil.getString("Last name : (" + p1.getLastName() + ") ");
			if (!input.equals("")) {
				p1.setLastName(input);
			}

			input = KeyboardUtil.getString("Phone : (" + p1.getPhone() + ") ");
			if (!input.equals("")) {
				p1.setPhone(input);
			}

			input = KeyboardUtil.getString("Email : (" + p1.getBankname() + ") ");
			if (!input.equals("")) {
				p1.setBankname(input);
			}

			session.getTransaction().commit();
			System.out.println("Data updated back to the db.");

		}

	}
}
