package co.mouni.mait.programs;

import org.hibernate.Session;

import co.mouni.mait.entity.Person;
import co.mouni.mait.util.HibernateUtil;

public class P01_GetOnePerson {

	public static void main(String[] args) {
		Session session = HibernateUtil.getSession();

		int accno =99;
		Person p1 = (Person) session.get(Person.class, accno);

		if (p1 == null) {
			System.out.println("No data found!");
		} else {
			System.out.println("Name  = " + p1.getFirstName() + " "
					+ p1.getLastName());
			System.out.println("Phone = " + p1.getPhone());
			System.out.println("Email = " + p1.getBankname());
		}

	}

}
